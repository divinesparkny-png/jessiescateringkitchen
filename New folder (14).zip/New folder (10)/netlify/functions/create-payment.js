// File: netlify/functions/create-payment.js

const { Client, Environment } = require('square');

const client = new Client({
  environment: Environment.Sandbox, // Change to Environment.Production for live
  accessToken: process.env.SQUARE_ACCESS_TOKEN,
});

const { paymentsApi } = client;

exports.handler = async (event) => {
  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, body: 'Method Not Allowed' };
  }

  try {
    const { token, amountCents, description } = JSON.parse(event.body);

    if (!token || !amountCents) {
      throw new Error('Missing required fields');
    }

    const response = await paymentsApi.createPayment({
      sourceId: token,
      idempotencyKey: crypto.randomUUID(),
      amountMoney: {
        amount: BigInt(amountCents),
        currency: 'USD',
      },
      note: description || 'Jessie\'s Catering Kitchen Preorder',
      autocomplete: true,
    });

    return {
      statusCode: 200,
      body: JSON.stringify({ success: true }),
    };
  } catch (error) {
    console.error('Payment error:', error);
    return {
      statusCode: 500,
      body: JSON.stringify({
        success: false,
        error: error.message || 'Payment processing failed',
      }),
    };
  }
};