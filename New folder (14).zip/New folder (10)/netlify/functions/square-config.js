exports.handler = async (event) => {
  if (event.httpMethod !== "GET") {
    return {
      statusCode: 405,
      body: JSON.stringify({ success: false, error: "Method Not Allowed" }),
    };
  }

  const environment = process.env.SQUARE_ENV || "sandbox";

  return {
    statusCode: 200,
    body: JSON.stringify({
      success: true,
      environment,
      applicationId: process.env.SQUARE_APPLICATION_ID,
      locationId: process.env.SQUARE_LOCATION_ID,
      hasAccessToken: Boolean(process.env.SQUARE_ACCESS_TOKEN),
      scriptUrl:
        environment === "production"
          ? "https://web.squarecdn.com/v1/square.js"
          : "https://sandbox.web.squarecdn.com/v1/square.js",
    }),
  };
};


